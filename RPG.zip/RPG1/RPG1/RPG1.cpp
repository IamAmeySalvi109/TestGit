// RPG1.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include<iostream>
#include<cstdlib>
#include<cmath>
#include<ctime>

using namespace std;
int main()
{

	int enemy_health = 100;				//initial Enemy Health
	int player_health = 100;			//initial Player Health 
	int enemy_attack = 0;				//Enemy Attack Strength
	int player_attack = 0;				//Player Attack Strength
	int selection = 0;					//Selection Variable for Battle Menu
	int heal_power = 0;					//Healing power Variable
	int enemy_selection = 0;			//Enemies battle menu selection variable
	int counter = 0;					//Counter to establish who's turn it is 
	int item_select = 0;				//Item inventory selection
	int enemy_mana = 50;				//Enemies magic meter
	int player_mana = 50;				//Players magic meter


	cout << player_health << "        " << enemy_health << endl;  //player and enemy health levels
	cout << player_mana << "         " << enemy_mana << endl;    //player and enemy magic levels
	cout << endl;
	cout << endl;
	cout << "1.Attack" << endl;								     //menu
	cout << "2.Heal" << endl;
	cout << "3.Inventory" << endl;
	cout << endl;

	do															 //start of loop
	{

		if (counter == 0)				// if the counter variable is 0 it is the players turn
		{
			cin >> selection;
			srand(static_cast<int>(time(0)));			//randomize all the random variables

			switch (selection)
			{
			case 1:// player chooses to ATTACK
				player_attack = 1 + rand() % (25);//attack power can be between 1-25
				cout << "ATTACK " << player_attack << endl;
				system("pause");
				system("cls");
				enemy_health = enemy_health - player_attack;
				cout << player_health << "        " << enemy_health << endl;
				cout << player_mana << "        " << enemy_mana << endl;
				cout << endl;
				cout << endl;
				cout << "1.Attack" << endl;
				cout << "2.Heal" << endl;
				cout << "3.Item" << endl;
				break;


			case 2://Player chooses to heal, it costs 10 magic to heal so if you dont have enough magic you loose a turn
				if (player_mana>9)
				{
					heal_power = 1 + rand() % (10);//healing power can be any number between 1-10
					cout << "HEAL" << heal_power << endl;
					system("pause");
					system("cls");
					player_health = player_health + heal_power;
					player_mana = player_mana - 10;
					cout << player_health << "        " << enemy_health << endl;
					cout << player_mana << "        " << enemy_mana << endl;
					cout << endl;
					cout << endl;
					cout << "1.Attack" << endl;
					cout << "2.Heal" << endl;
					cout << "3.Item" << endl;
				}																				//endIF
				break;

			case 3:// if player chooses to use item inventory system
				cout << "ITEM INVENTORY" << endl;
				cout << "1.Potion       :     Restores HP" << endl;
				cout << "2.Ether        :     Restores Mana" << endl;
				cout << "3.Bomb         :     Causes Damage to all players" << endl;

				cin >> item_select;
				switch (item_select)
				{
				case 1:
					player_health = player_health + 25;
					system("cls");
					cout << player_health << "        " << enemy_health << endl;
					cout << player_mana << "        " << enemy_mana << endl;
					cout << endl;
					cout << endl;
					cout << "1.Attack" << endl;
					cout << "2.Heal" << endl;
					cout << "3.Item" << endl;
					break;
				
				case 2:
					player_mana = player_mana + 10;
					system("cls");
					cout << player_health << "        " << enemy_health << endl;
					cout << player_mana << "        " << enemy_mana << endl;
					cout << endl;
					cout << endl;
					cout << "1.Attack" << endl;
					cout << "2.Heal" << endl;
					cout << "3.Item" << endl;
					break;

				case 3:
					player_health = player_health - (1 + rand() % 25);
					enemy_health = enemy_health - (1 + rand() % 25);
					system("cls");
					cout << player_health << "        " << enemy_health << endl;
					cout << player_mana << "        " << enemy_mana << endl;
					cout << endl;
					cout << endl;
					cout << "1.Attack" << endl;
					cout << "2.Heal" << endl;
					cout << "3.Item" << endl;
					break;
				}
				
				      
			}												//endSelectionSwitch
			counter = 1;									//advances the counter to 1 to allow the enemies turn
		}													//endif
		enemy_selection = rand() % 2 + 1;
		
		switch (enemy_selection)
		{
		case 1:
			enemy_attack = 1 + rand() % (25);				//attack power can be between 1-25
			cout << "ATTACK " << enemy_attack << endl;
			system("pause");
			system("cls");
			player_health = player_health - enemy_attack;
			cout << player_health << "        " << enemy_health << endl;
			cout << player_mana << "        " << enemy_mana << endl;
			cout << endl;
			cout << endl;
			cout << "1.Attack" << endl;
			cout << "2.Heal" << endl;
			cout << "3.Item" << endl;
			break;

		case 2:

			if (enemy_mana>9)
			{
				heal_power = 1 + rand() % (10);
				cout << "HEAL" << heal_power << endl;
				system("pause");
				system("cls");
				enemy_mana = enemy_mana - 10;
				enemy_health = enemy_health + heal_power;
				cout << player_health << "        " << enemy_health << endl;
				cout << player_mana << "        " << enemy_mana << endl;
				cout << endl;
				cout << endl;
				cout << "1.Attack" << endl;
				cout << "2.Heal" << endl;
				cout << "3.Item" << endl;
			}
			break;
		}												//endeSelectionSwitch
		counter = 0;
	} while (enemy_health > 1 && player_health > 1);	//loop end
	
	cout << endl;
	cout << endl;

	if (player_health < 0)
		cout << "YOU LOSE" << endl;
	else
		cout << "YOU WIN THIS BATTLE" << endl;

	cout << endl;
	system("pause");
	return 0;
}